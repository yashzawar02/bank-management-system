/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bank;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Ravi Shekhar
 */
@Entity
@Table(name = "new_table", catalog = "bank", schema = "")
@NamedQueries({
    @NamedQuery(name = "NewTable.findAll", query = "SELECT n FROM NewTable n")
    , @NamedQuery(name = "NewTable.findByUsername", query = "SELECT n FROM NewTable n WHERE n.username = :username")
    , @NamedQuery(name = "NewTable.findByPassword", query = "SELECT n FROM NewTable n WHERE n.password = :password")
    , @NamedQuery(name = "NewTable.findByAccountType", query = "SELECT n FROM NewTable n WHERE n.accountType = :accountType")
    , @NamedQuery(name = "NewTable.findByName", query = "SELECT n FROM NewTable n WHERE n.name = :name")
    , @NamedQuery(name = "NewTable.findByNationality", query = "SELECT n FROM NewTable n WHERE n.nationality = :nationality")
    , @NamedQuery(name = "NewTable.findByMobile", query = "SELECT n FROM NewTable n WHERE n.mobile = :mobile")
    , @NamedQuery(name = "NewTable.findByAddress", query = "SELECT n FROM NewTable n WHERE n.address = :address")
    , @NamedQuery(name = "NewTable.findByBranchName", query = "SELECT n FROM NewTable n WHERE n.branchName = :branchName")})
public class NewTable implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "username")
    private String username;
    @Basic(optional = false)
    @Column(name = "password")
    private String password;
    @Basic(optional = false)
    @Column(name = "account_type")
    private String accountType;
    @Basic(optional = false)
    @Column(name = "name")
    private String name;
    @Basic(optional = false)
    @Column(name = "nationality")
    private String nationality;
    @Basic(optional = false)
    @Column(name = "mobile")
    private String mobile;
    @Basic(optional = false)
    @Column(name = "address")
    private String address;
    @Basic(optional = false)
    @Column(name = "branch_name")
    private String branchName;

    public NewTable() {
    }

    public NewTable(String username) {
        this.username = username;
    }

    public NewTable(String username, String password, String accountType, String name, String nationality, String mobile, String address, String branchName) {
        this.username = username;
        this.password = password;
        this.accountType = accountType;
        this.name = name;
        this.nationality = nationality;
        this.mobile = mobile;
        this.address = address;
        this.branchName = branchName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        String oldUsername = this.username;
        this.username = username;
        changeSupport.firePropertyChange("username", oldUsername, username);
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        String oldPassword = this.password;
        this.password = password;
        changeSupport.firePropertyChange("password", oldPassword, password);
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        String oldAccountType = this.accountType;
        this.accountType = accountType;
        changeSupport.firePropertyChange("accountType", oldAccountType, accountType);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        String oldName = this.name;
        this.name = name;
        changeSupport.firePropertyChange("name", oldName, name);
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        String oldNationality = this.nationality;
        this.nationality = nationality;
        changeSupport.firePropertyChange("nationality", oldNationality, nationality);
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        String oldMobile = this.mobile;
        this.mobile = mobile;
        changeSupport.firePropertyChange("mobile", oldMobile, mobile);
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        String oldAddress = this.address;
        this.address = address;
        changeSupport.firePropertyChange("address", oldAddress, address);
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        String oldBranchName = this.branchName;
        this.branchName = branchName;
        changeSupport.firePropertyChange("branchName", oldBranchName, branchName);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (username != null ? username.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof NewTable)) {
            return false;
        }
        NewTable other = (NewTable) object;
        if ((this.username == null && other.username != null) || (this.username != null && !this.username.equals(other.username))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "bank.NewTable[ username=" + username + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
